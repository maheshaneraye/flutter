"""
Q10. Heart Disease Risk Prediction with Logistic Regression
------------------------------------------------------------------
Scenario : A health startup wants to assess heart disease risk.
Task     : Use logistic regression on patient data (age, cholesterol,
           blood pressure) to predict risk levels (High risk / Low risk).

WHY LOGISTIC REGRESSION?
We need a Yes/No (High risk / Low risk) output, and logistic regression
gives us both the class AND the probability, which is very useful in
healthcare to communicate risk levels rather than a blunt yes/no.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, roc_curve, roc_auc_score
import matplotlib.pyplot as plt

# ---------- 1. Create synthetic patient data ----------
np.random.seed(10)
n = 300
age = np.random.randint(25, 80, n)
cholesterol = np.random.randint(150, 320, n)
blood_pressure = np.random.randint(90, 200, n)

risk_score = (
    (age > 55).astype(int) +
    (cholesterol > 240).astype(int) +
    (blood_pressure > 140).astype(int)
)
high_risk = (risk_score >= 2).astype(int)   # 1 = high risk, 0 = low risk

df = pd.DataFrame({
    "Age": age, "Cholesterol": cholesterol,
    "BloodPressure": blood_pressure, "HighRisk": high_risk
})
print(df.head())

# ---------- 2. Features & target ----------
X = df[["Age", "Cholesterol", "BloodPressure"]]
y = df["HighRisk"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

# ---------- 3. Scale features ----------
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ---------- 4. Train Logistic Regression ----------
model = LogisticRegression()
model.fit(X_train_scaled, y_train)

# ---------- 5. Predict & Evaluate ----------
y_pred = model.predict(X_test_scaled)
y_proba = model.predict_proba(X_test_scaled)[:, 1]

print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))
print("ROC-AUC:", roc_auc_score(y_test, y_proba))

# ---------- 6. Plot ROC curve (shows model's ability to separate classes) ----------
fpr, tpr, _ = roc_curve(y_test, y_proba)
plt.plot(fpr, tpr, label=f"ROC Curve (AUC = {roc_auc_score(y_test, y_proba):.2f})")
plt.plot([0, 1], [0, 1], 'r--', label="Random Guess")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve - Heart Disease Risk Prediction")
plt.legend()
plt.savefig("heart_disease_roc_curve.png", dpi=150, bbox_inches='tight')
print("Chart saved as heart_disease_roc_curve.png")

# ---------- 7. Predict risk for one new patient ----------
new_patient = pd.DataFrame({"Age": [62], "Cholesterol": [260], "BloodPressure": [150]})
new_patient_scaled = scaler.transform(new_patient)
prob = model.predict_proba(new_patient_scaled)[0][1]
print(f"\nNew patient's heart disease risk probability: {prob*100:.1f}%")
