"""
Q8. Stock Price Forecasting with Least Squares
----------------------------------------------------
Scenario : A financial analyst wants to forecast stock prices.
Task     : Use least squares regression on historical stock data (day number
           vs closing price) to predict future trends.

WHY LEAST SQUARES?
"Least Squares" is the mathematical METHOD used internally by Linear
Regression to find the best-fit line -- it minimizes the sum of the
SQUARED differences between actual and predicted values (the "errors").
Here we show it in two ways:
  (a) using plain NumPy (np.polyfit) to show the raw maths, AND
  (b) using sklearn's LinearRegression (which uses least squares internally)
so you understand what is happening "under the hood".
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# ---------- 1. Create synthetic historical stock data ----------
np.random.seed(3)
days = np.arange(1, 101)                       # day 1 to day 100
trend = 100 + days * 1.5                          # underlying upward trend
noise = np.random.normal(0, 8, len(days))         # random daily fluctuation
closing_price = trend + noise

df = pd.DataFrame({"Day": days, "ClosingPrice": closing_price})
print(df.head())

# ---------- 2(a). METHOD 1: Least Squares using plain NumPy ----------
# np.polyfit(x, y, degree=1) fits y = m*x + c using the least squares method
m, c = np.polyfit(df["Day"], df["ClosingPrice"], 1)
print(f"\n[NumPy least squares] Slope (m) = {m:.3f}, Intercept (c) = {c:.3f}")
print(f"Equation: Price = {m:.3f} * Day + {c:.3f}")

# ---------- 2(b). METHOD 2: Same thing using scikit-learn ----------
X = df[["Day"]]     # sklearn needs 2D input for features
y = df["ClosingPrice"]

model = LinearRegression()
model.fit(X, y)
print(f"\n[sklearn] Slope = {model.coef_[0]:.3f}, Intercept = {model.intercept_:.3f}")

# ---------- 3. Evaluate model fit ----------
y_pred = model.predict(X)
print("\nRMSE:", np.sqrt(mean_squared_error(y, y_pred)))
print("R^2 Score:", r2_score(y, y_pred))

# ---------- 4. Forecast future prices (next 10 days) ----------
future_days = pd.DataFrame({"Day": np.arange(101, 111)})
future_predictions = model.predict(future_days)
print("\nForecast for next 10 days:")
for d, p in zip(future_days["Day"], future_predictions):
    print(f"  Day {d}: Predicted Price = {p:.2f}")

# ---------- 5. Plot historical data + trend line + forecast ----------
plt.figure(figsize=(10, 5))
plt.scatter(df["Day"], df["ClosingPrice"], label="Historical Prices", alpha=0.6)
plt.plot(df["Day"], y_pred, color='green', label="Fitted Least-Squares Line")
plt.plot(future_days["Day"], future_predictions, color='red', linestyle='--', label="Forecast")
plt.xlabel("Day")
plt.ylabel("Stock Closing Price")
plt.title("Stock Price Forecasting using Least Squares Regression")
plt.legend()
plt.savefig("least_squares_stock_forecast.png", dpi=150, bbox_inches='tight')
print("\nChart saved as least_squares_stock_forecast.png")
