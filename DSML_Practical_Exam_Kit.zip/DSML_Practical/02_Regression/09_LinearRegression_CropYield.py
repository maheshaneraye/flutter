"""
Q9. Crop Yield Estimation Using Linear Regression
------------------------------------------------------
Scenario : An agricultural agency wants to predict crop yields.
Task     : Model yield (tons/acre) based on rainfall (mm), temperature (C),
           and soil quality index (1-10).

WHY LINEAR REGRESSION?
We're predicting a continuous number (yield in tons/acre), and we assume
rainfall/temperature/soil quality each contribute additively to the yield.
Linear Regression also lets us clearly interpret HOW MUCH each factor
affects yield through its coefficient -- useful for advising farmers.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.pyplot as plt

# ---------- 1. Create synthetic agricultural data ----------
np.random.seed(5)
n = 150
rainfall = np.random.uniform(300, 1500, n)          # mm of rainfall per season
temperature = np.random.uniform(15, 40, n)            # avg temperature in Celsius
soil_quality = np.random.randint(1, 11, n)             # soil quality index (1-10)

# True relationship (yield increases with rainfall & soil quality,
# but too much heat reduces yield) + noise
yield_tons = (
    0.003 * rainfall
    + 0.4 * soil_quality
    - 0.05 * (temperature - 25) ** 2 / 10   # penalty for extreme temperature
    + 3
    + np.random.normal(0, 0.5, n)
)
yield_tons = np.clip(yield_tons, 0, None)   # yield can't be negative

df = pd.DataFrame({
    "Rainfall_mm": rainfall,
    "Temperature_C": temperature,
    "SoilQuality": soil_quality,
    "Yield_tons_per_acre": yield_tons
})
print(df.head())

# ---------- 2. Features & target ----------
X = df[["Rainfall_mm", "Temperature_C", "SoilQuality"]]
y = df["Yield_tons_per_acre"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ---------- 3. Train Linear Regression ----------
model = LinearRegression()
model.fit(X_train, y_train)

print("\nIntercept:", model.intercept_)
print("Coefficients:", dict(zip(X.columns, model.coef_)))

# ---------- 4. Predict & Evaluate ----------
y_pred = model.predict(X_test)
print("\nMAE:", mean_absolute_error(y_test, y_pred))
print("R^2 Score:", r2_score(y_test, y_pred))

# ---------- 5. Plot actual vs predicted yield ----------
plt.scatter(y_test, y_pred, alpha=0.6, color='green')
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--')
plt.xlabel("Actual Yield (tons/acre)")
plt.ylabel("Predicted Yield (tons/acre)")
plt.title("Crop Yield: Actual vs Predicted")
plt.savefig("crop_yield_actual_vs_predicted.png", dpi=150, bbox_inches='tight')
print("Chart saved as crop_yield_actual_vs_predicted.png")

# ---------- 6. Predict yield for a new field ----------
new_field = pd.DataFrame({"Rainfall_mm": [900], "Temperature_C": [27], "SoilQuality": [8]})
predicted_yield = model.predict(new_field)
print(f"\nPredicted yield for new field: {predicted_yield[0]:.2f} tons/acre")
