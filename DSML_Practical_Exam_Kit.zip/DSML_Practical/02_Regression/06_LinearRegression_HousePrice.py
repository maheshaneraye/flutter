"""
Q6. House Price Prediction Using Linear Regression
------------------------------------------------------
Scenario : A real estate firm wants to estimate property prices.
Task     : Use linear regression to predict prices based on location score,
           size (sq. ft.), and number of amenities.

WHY LINEAR REGRESSION?
Linear Regression fits a straight-line relationship:
    Price = b0 + b1*Size + b2*LocationScore + b3*Amenities
It's the standard first choice whenever the target (price) is a
CONTINUOUS number and we believe the relationship with inputs is roughly linear.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib.pyplot as plt

# ---------- 1. Create synthetic housing data ----------
np.random.seed(0)
n = 200
size_sqft = np.random.randint(500, 4000, n)
location_score = np.random.randint(1, 10, n)     # 1 = poor area, 10 = prime area
amenities = np.random.randint(0, 8, n)             # number of amenities (gym, pool..)

# True underlying relationship + random noise (simulates real-world data)
price = (
    50000
    + size_sqft * 120
    + location_score * 80000
    + amenities * 15000
    + np.random.normal(0, 50000, n)      # noise
)

df = pd.DataFrame({
    "Size_sqft": size_sqft,
    "LocationScore": location_score,
    "Amenities": amenities,
    "Price": price
})
print(df.head())

# ---------- 2. Features & target ----------
X = df[["Size_sqft", "LocationScore", "Amenities"]]
y = df["Price"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ---------- 3. Train Linear Regression ----------
model = LinearRegression()
model.fit(X_train, y_train)

# ---------- 4. Inspect the learned equation ----------
print("\nIntercept (b0):", model.intercept_)
print("Coefficients (b1, b2, b3):", dict(zip(X.columns, model.coef_)))

# ---------- 5. Predict & Evaluate ----------
y_pred = model.predict(X_test)
print("\nMAE  (Mean Absolute Error):", mean_absolute_error(y_test, y_pred))
print("MSE  (Mean Squared Error):", mean_squared_error(y_test, y_pred))
print("RMSE (Root Mean Squared Error):", np.sqrt(mean_squared_error(y_test, y_pred)))
print("R^2 Score (1.0 = perfect fit):", r2_score(y_test, y_pred))

# ---------- 6. Plot actual vs predicted prices ----------
plt.scatter(y_test, y_pred, alpha=0.6)
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--')  # perfect-prediction line
plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.title("Actual vs Predicted House Prices")
plt.savefig("linear_regression_house_price.png", dpi=150, bbox_inches='tight')
print("\nChart saved as linear_regression_house_price.png")

# ---------- 7. Predict price of a brand-new house ----------
new_house = pd.DataFrame({"Size_sqft": [1800], "LocationScore": [7], "Amenities": [3]})
predicted_price = model.predict(new_house)
print(f"\nPredicted price for new house: Rs. {predicted_price[0]:,.0f}")
