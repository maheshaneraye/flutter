"""
Q7. Churn Probability with Logistic Regression
--------------------------------------------------
Scenario : A telecom company wants to predict customer churn (customer leaving).
Task     : Apply logistic regression to model churn likelihood using usage
           minutes and monthly billing amount.

WHY LOGISTIC REGRESSION (not linear)?
Even though it has "regression" in the name, Logistic Regression is used
for CLASSIFICATION (Churn = Yes/No), not for predicting a raw number.
It uses the "sigmoid" function to squeeze any input into a probability
between 0 and 1, e.g. "this customer has a 82% chance of churning".
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, roc_auc_score

# ---------- 1. Create synthetic telecom customer data ----------
np.random.seed(7)
n = 300
usage_minutes = np.random.randint(0, 1000, n)      # monthly call usage
monthly_bill = np.random.uniform(200, 3000, n)      # monthly bill in Rs.
tenure_months = np.random.randint(1, 72, n)          # how long they've been a customer

# Rule: low usage + high bill + low tenure -> more likely to churn
churn_score = (
    (usage_minutes < 200).astype(int) +
    (monthly_bill > 2000).astype(int) +
    (tenure_months < 6).astype(int)
)
churn = (churn_score >= 2).astype(int)   # 1 = churned, 0 = stayed

df = pd.DataFrame({
    "UsageMinutes": usage_minutes,
    "MonthlyBill": monthly_bill,
    "TenureMonths": tenure_months,
    "Churn": churn
})
print(df.head())

# ---------- 2. Features & target ----------
X = df[["UsageMinutes", "MonthlyBill", "TenureMonths"]]
y = df["Churn"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

# ---------- 3. Scale features (helps logistic regression converge faster) ----------
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ---------- 4. Train Logistic Regression ----------
model = LogisticRegression()
model.fit(X_train_scaled, y_train)

# ---------- 5. Predict classes AND probabilities ----------
y_pred = model.predict(X_test_scaled)
y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]   # probability of churn (class 1)

# ---------- 6. Evaluate ----------
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))
print("ROC-AUC Score:", roc_auc_score(y_test, y_pred_proba))

# ---------- 7. Predict for one new customer ----------
new_customer = pd.DataFrame({"UsageMinutes": [150], "MonthlyBill": [2500], "TenureMonths": [3]})
new_customer_scaled = scaler.transform(new_customer)
prob = model.predict_proba(new_customer_scaled)[0][1]
print(f"\nNew customer churn probability: {prob*100:.1f}%")
