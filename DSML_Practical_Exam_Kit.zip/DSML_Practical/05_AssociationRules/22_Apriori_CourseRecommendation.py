"""
Q22. Online Course Recommendation
----------------------------------------
Scenario : An ed-tech platform wants to suggest relevant courses.
Task     : Mine user enrollment data to find course associations
           (e.g. "students who take Python also take Data Science").

WHY APRIORI?
Each "transaction" here is one STUDENT'S set of enrolled courses. Finding
frequent course combinations lets the platform recommend "students who
took this course also took..." -- the same logic used by e-commerce
recommendation engines, applied to education.
"""

import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# ---------- 1. Sample student enrollment data ----------
enrollments = [
    ["python", "data_science", "statistics"],
    ["python", "web_development"],
    ["data_science", "statistics", "machine_learning"],
    ["python", "data_science", "machine_learning"],
    ["web_development", "javascript"],
    ["python", "data_science", "statistics", "machine_learning"],
    ["python", "web_development", "javascript"],
    ["data_science", "machine_learning"],
    ["python", "statistics"],
    ["python", "data_science"],
]

# ---------- 2. One-hot encode ----------
te = TransactionEncoder()
te_array = te.fit(enrollments).transform(enrollments)
df = pd.DataFrame(te_array, columns=te.columns_)
print("Encoded enrollments:\n", df)

# ---------- 3. Find frequent course combinations ----------
frequent_itemsets = apriori(df, min_support=0.3, use_colnames=True)
print("\nFrequent Course Sets:\n", frequent_itemsets.sort_values("support", ascending=False))

# ---------- 4. Generate recommendation rules ----------
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.6)
rules = rules.sort_values("lift", ascending=False)
print("\nCourse Recommendation Rules:\n",
      rules[["antecedents", "consequents", "support", "confidence", "lift"]])

# ---------- 5. Recommend a course for a student who took "python" ----------
python_rules = rules[rules["antecedents"] == frozenset({"python"})]
if len(python_rules) > 0:
    print("\nStudents who took 'python' should also be recommended:")
    print(python_rules[["consequents", "confidence"]])
