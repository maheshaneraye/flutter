"""
Q23. Retail Loss Prevention
-----------------------------
Scenario : A store wants to detect suspicious buying patterns.
Task     : Use association rules to identify UNUSUAL item combinations
           that are linked to theft (e.g. items commonly stolen together,
           or combinations that don't make normal shopping sense).

WHY APRIORI (used a bit differently here)?
Normally Apriori finds "expected" frequent patterns. For loss-prevention,
we instead look at rules with HIGH LIFT but LOW SUPPORT -- meaning the
combination is rare overall, but when it DOES happen, the items are
strongly linked together in a way that doesn't match typical shopping
behaviour (a useful signal for the loss-prevention team to investigate).
"""

import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# ---------- 1. Sample transactions, including some flagged as "suspicious" ----------
transactions = [
    ["milk", "bread", "eggs"],
    ["milk", "bread"],
    ["gift_card", "battery", "razor_blades"],      # unusual small high-value combo
    ["bread", "eggs", "butter"],
    ["gift_card", "battery"],                        # repeats the unusual combo
    ["milk", "eggs"],
    ["perfume", "gift_card", "battery"],             # unusual combo again
    ["bread", "butter"],
    ["milk", "bread", "butter"],
    ["gift_card", "razor_blades"],
]

# ---------- 2. One-hot encode ----------
te = TransactionEncoder()
te_array = te.fit(transactions).transform(transactions)
df = pd.DataFrame(te_array, columns=te.columns_)

# ---------- 3. Find frequent itemsets (use a LOW min_support to catch rare patterns) ----------
frequent_itemsets = apriori(df, min_support=0.15, use_colnames=True)
print("Frequent Itemsets:\n", frequent_itemsets.sort_values("support", ascending=False))

# ---------- 4. Generate rules and sort by LIFT (not confidence) ----------
# High lift = items are bought together far more than random chance would suggest
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1.5)
rules = rules.sort_values("lift", ascending=False)
print("\nAll Rules (sorted by lift):\n",
      rules[["antecedents", "consequents", "support", "confidence", "lift"]])

# ---------- 5. Flag suspicious combinations: high lift + low support ----------
suspicious = rules[(rules["lift"] > 2) & (rules["support"] < 0.3)]
print("\n--- SUSPICIOUS COMBINATIONS TO INVESTIGATE ---")
print(suspicious[["antecedents", "consequents", "support", "lift"]])
