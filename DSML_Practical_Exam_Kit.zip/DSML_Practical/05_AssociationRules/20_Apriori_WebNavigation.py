"""
Q20. Web Navigation Pattern Mining
----------------------------------------
Scenario : A website wants to improve user experience.
Task     : Apply association rule mining to discover common navigation
           paths (which pages are usually visited together in one session).

WHY APRIORI (same idea as market basket, applied to web pages)?
Instead of "items in a shopping cart", here each "transaction" is one
user's SESSION, and the "items" are the PAGES they visited during that
session. Apriori then finds which pages tend to be visited together,
helping the website team decide on better internal links / page layout.
"""

import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# ---------- 1. Sample user sessions (pages visited by each user) ----------
sessions = [
    ["home", "products", "cart", "checkout"],
    ["home", "about", "contact"],
    ["home", "products", "product_detail", "cart"],
    ["home", "products", "cart", "checkout"],
    ["home", "blog", "about"],
    ["home", "products", "product_detail", "cart", "checkout"],
    ["home", "products", "product_detail"],
    ["home", "contact"],
    ["home", "products", "cart"],
    ["home", "blog", "products"],
]

# ---------- 2. One-hot encode the sessions ----------
te = TransactionEncoder()
te_array = te.fit(sessions).transform(sessions)
df = pd.DataFrame(te_array, columns=te.columns_)
print("Encoded sessions:\n", df)

# ---------- 3. Find frequent page-visit combinations ----------
frequent_itemsets = apriori(df, min_support=0.3, use_colnames=True)
print("\nFrequent Page Sets:\n", frequent_itemsets.sort_values("support", ascending=False))

# ---------- 4. Generate navigation rules ----------
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.6)
rules = rules.sort_values("lift", ascending=False)
print("\nNavigation Rules:\n",
      rules[["antecedents", "consequents", "support", "confidence", "lift"]])

# ---------- 5. Business insight ----------
if len(rules) > 0:
    top = rules.iloc[0]
    print(f"\nInsight: Visitors who go to {set(top['antecedents'])} usually also visit "
          f"{set(top['consequents'])} -> place a quick link between these pages!")
