"""
Q21. Medical Prescription Pattern Discovery
--------------------------------------------------
Scenario : A hospital wants to analyze co-prescribed drugs.
Task     : Use association rules to find frequent drug combinations
           prescribed together.

WHY APRIORI?
Just like grocery items bought together, drugs prescribed together in
the same patient visit ("transaction") can reveal common treatment
combinations (e.g. "Paracetamol is often co-prescribed with Vitamin C
during flu season") -- useful for pharmacy stock planning and for
flagging unusual/risky combinations.
"""

import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# ---------- 1. Sample prescriptions (each list = drugs given in one visit) ----------
prescriptions = [
    ["paracetamol", "vitaminC", "cough_syrup"],
    ["amoxicillin", "paracetamol"],
    ["paracetamol", "vitaminC"],
    ["metformin", "insulin"],
    ["amoxicillin", "paracetamol", "cough_syrup"],
    ["metformin", "vitaminD"],
    ["paracetamol", "vitaminC", "vitaminD"],
    ["amoxicillin", "cough_syrup"],
    ["metformin", "insulin", "vitaminD"],
    ["paracetamol", "cough_syrup"],
]

# ---------- 2. One-hot encode prescriptions ----------
te = TransactionEncoder()
te_array = te.fit(prescriptions).transform(prescriptions)
df = pd.DataFrame(te_array, columns=te.columns_)
print("Encoded prescriptions:\n", df)

# ---------- 3. Find frequent drug combinations ----------
frequent_itemsets = apriori(df, min_support=0.3, use_colnames=True)
print("\nFrequent Drug Combinations:\n", frequent_itemsets.sort_values("support", ascending=False))

# ---------- 4. Generate association rules ----------
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.6)
rules = rules.sort_values("lift", ascending=False)
print("\nPrescription Rules:\n",
      rules[["antecedents", "consequents", "support", "confidence", "lift"]])

# ---------- 5. Interpret findings ----------
if len(rules) > 0:
    top = rules.iloc[0]
    print(f"\nInsight: Patients prescribed {set(top['antecedents'])} are often also "
          f"prescribed {set(top['consequents'])} (confidence={top['confidence']:.2f})")
