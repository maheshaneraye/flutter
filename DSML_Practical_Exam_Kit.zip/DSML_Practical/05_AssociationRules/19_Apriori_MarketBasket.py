"""
Q19. Market Basket Analysis for Retail
--------------------------------------------
Scenario : A supermarket wants to optimize product placement.
Task     : Use the Apriori algorithm to find frequent itemsets and generate
           association rules (e.g. "customers who buy bread also buy butter").

WHY APRIORI?
Apriori scans transactions (shopping carts) to find combinations of items
that are frequently bought TOGETHER. It uses 3 key metrics:
  - Support    : how often the itemset appears in all transactions
  - Confidence : P(buy Y | already bought X)  -- how reliable the rule is
  - Lift       : how much MORE likely Y is bought when X is bought,
                 compared to Y being bought on its own (lift > 1 = useful rule)

INSTALL NOTE: this script needs the 'mlxtend' library.
    pip install mlxtend --break-system-packages
"""

import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# ---------- 1. Sample transactions (each list = one customer's shopping basket) ----------
transactions = [
    ["bread", "milk", "butter"],
    ["bread", "diapers", "beer", "eggs"],
    ["milk", "diapers", "beer", "cola"],
    ["bread", "milk", "diapers", "beer"],
    ["bread", "milk", "diapers", "cola"],
    ["milk", "butter", "bread"],
    ["bread", "butter"],
    ["beer", "diapers"],
    ["bread", "milk", "butter", "eggs"],
    ["milk", "diapers", "beer"],
]

# ---------- 2. Convert transactions into a one-hot encoded table ----------
# Each row = one transaction, each column = one item (True/False if bought)
te = TransactionEncoder()
te_array = te.fit(transactions).transform(transactions)
df = pd.DataFrame(te_array, columns=te.columns_)
print("One-hot encoded transactions:\n", df)

# ---------- 3. Find frequent itemsets using Apriori ----------
# min_support=0.3 means: keep itemsets that appear in at least 30% of transactions
frequent_itemsets = apriori(df, min_support=0.3, use_colnames=True)
frequent_itemsets = frequent_itemsets.sort_values("support", ascending=False)
print("\nFrequent Itemsets:\n", frequent_itemsets)

# ---------- 4. Generate association rules from frequent itemsets ----------
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.6)
rules = rules.sort_values("lift", ascending=False)
print("\nAssociation Rules:\n",
      rules[["antecedents", "consequents", "support", "confidence", "lift"]])

# ---------- 5. Interpret the top rule in plain English ----------
if len(rules) > 0:
    top = rules.iloc[0]
    print(f"\nTop Rule: If a customer buys {set(top['antecedents'])}, "
          f"they are also likely to buy {set(top['consequents'])} "
          f"(confidence={top['confidence']:.2f}, lift={top['lift']:.2f})")
