"""
Q2. Loan Default Prediction with Decision Trees
------------------------------------------------
Scenario : A bank needs to assess loan applicants for risk of default.
Task     : Use a Decision Tree to classify applicants (Default / No Default)
           based on income, credit score, and employment history (years).

WHY DECISION TREE?
A Decision Tree asks a series of yes/no questions on the features
(e.g. "Is credit score < 600?") and splits the data step by step until it
reaches a decision. It is easy to visualize and explain to bank managers,
which is exactly why banks like using it for loan approval decisions.

Since we don't have a real bank dataset in the exam, we CREATE our own
synthetic dataset using simple rules + randomness. This is a very common
and acceptable exam technique when no CSV file is provided.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt

# ---------- 1. Create a synthetic loan dataset ----------
np.random.seed(42)
n = 300  # number of applicants

income = np.random.randint(15000, 120000, n)              # monthly income
credit_score = np.random.randint(300, 900, n)              # credit score
employment_years = np.random.randint(0, 25, n)              # years employed

# Rule of thumb used ONLY to create labels for our fake data:
# Low income + low credit score + little job history => higher default risk
default_prob = (
    (income < 30000).astype(int) +
    (credit_score < 550).astype(int) +
    (employment_years < 2).astype(int)
)
default = (default_prob >= 2).astype(int)  # 1 = defaults, 0 = pays back

df = pd.DataFrame({
    "Income": income,
    "CreditScore": credit_score,
    "EmploymentYears": employment_years,
    "Default": default
})
print(df.head())

# ---------- 2. Split features (X) and target (y) ----------
X = df[["Income", "CreditScore", "EmploymentYears"]]
y = df["Default"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

# ---------- 3. Train the Decision Tree ----------
# max_depth limits how many questions deep the tree can go -- prevents overfitting
model = DecisionTreeClassifier(criterion='gini', max_depth=4, random_state=42)
model.fit(X_train, y_train)

# ---------- 4. Predict & Evaluate ----------
y_pred = model.predict(X_test)
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# ---------- 5. Feature importance (which factor matters most?) ----------
importance = pd.Series(model.feature_importances_, index=X.columns)
print("\nFeature Importance:\n", importance.sort_values(ascending=False))

# ---------- 6. Visualize the tree (saved as an image) ----------
plt.figure(figsize=(14, 8))
plot_tree(model, feature_names=X.columns, class_names=["No Default", "Default"],
          filled=True, rounded=True)
plt.title("Decision Tree - Loan Default Prediction")
plt.savefig("decision_tree_loan.png", dpi=150, bbox_inches='tight')
print("\nTree diagram saved as decision_tree_loan.png")
