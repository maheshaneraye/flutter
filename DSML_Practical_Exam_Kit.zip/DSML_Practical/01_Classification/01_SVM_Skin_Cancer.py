"""
Q1. Medical Diagnosis Using SVM
--------------------------------
Scenario : A hospital wants to automate diagnosis of skin cancer using image data.
Task     : Train an SVM to classify skin lesions as benign (0) or malignant (1)
           using image "features" (numeric values extracted from the image,
           e.g. texture, radius, smoothness -- similar to the real-world
           Breast Cancer Wisconsin dataset).

WHY SVM?
SVM (Support Vector Machine) finds the best line/boundary (called a
"hyperplane") that separates two classes with the maximum possible gap
("margin") between them. It works very well for medical image-feature data
because such data is usually high-dimensional and SVM handles that nicely.

We use scikit-learn's built-in Breast Cancer dataset as a stand-in for
"skin lesion image features" -- it has the exact same structure
(numeric features -> benign/malignant label) that this question expects.
"""

# ---------- 1. Import required libraries ----------
from sklearn.datasets import load_breast_cancer      # ready-made medical dataset
from sklearn.model_selection import train_test_split  # to split data into train/test
from sklearn.preprocessing import StandardScaler       # to scale features
from sklearn.svm import SVC                             # the SVM classifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# ---------- 2. Load the dataset ----------
data = load_breast_cancer()
X = data.data          # feature matrix (30 numeric image-derived features)
y = data.target         # 0 = malignant, 1 = benign (as defined by sklearn)

print("Feature names (first 5):", data.feature_names[:5])
print("Total samples:", X.shape[0], " | Total features:", X.shape[1])

# ---------- 3. Split into training and testing sets ----------
# 80% data for training the model, 20% for testing how well it learned
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ---------- 4. Feature scaling ----------
# SVM is distance-based, so features must be on the same scale
# (e.g. "radius" in mm vs "area" in mm^2 have very different ranges)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)   # learn mean/std from train data & apply
X_test = scaler.transform(X_test)          # apply SAME scaling to test data

# ---------- 5. Train the SVM model ----------
# kernel='rbf' -> handles non-linear boundaries (common in medical data)
# C -> controls trade-off between smooth boundary and correctly classifying points
model = SVC(kernel='rbf', C=1.0, gamma='scale', random_state=42)
model.fit(X_train, y_train)

# ---------- 6. Make predictions on unseen (test) data ----------
y_pred = model.predict(X_test)

# ---------- 7. Evaluate the model ----------
print("\n--- MODEL EVALUATION ---")
print("Accuracy :", accuracy_score(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# ---------- 8. Predict a single new sample (simulating a new patient) ----------
sample = X_test[0].reshape(1, -1)
prediction = model.predict(sample)
label = "Benign" if prediction[0] == 1 else "Malignant"
print("Prediction for one new sample:", label)
