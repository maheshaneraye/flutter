"""
Q3. Disease Classification with KNN
-------------------------------------
Scenario : A clinic wants to predict whether a patient has diabetes.
Task     : Apply KNN (K-Nearest Neighbors) using glucose level, BMI, and age.

WHY KNN?
KNN classifies a new patient by looking at the "K" most similar
(nearest) patients in the training data and taking a majority vote of
their labels. It's simple, intuitive ("you are similar to your neighbours"),
and needs no real training phase -- great for a quick clinical screening tool.

We generate a synthetic dataset similar in spirit to the well-known
Pima Indians Diabetes dataset.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt

# ---------- 1. Create synthetic patient data ----------
np.random.seed(1)
n = 400
glucose = np.random.randint(70, 200, n)
bmi = np.random.uniform(15, 45, n)
age = np.random.randint(18, 80, n)

# Simple rule to create realistic labels: higher glucose/BMI/age -> more likely diabetic
risk_score = (glucose > 140).astype(int) + (bmi > 30).astype(int) + (age > 45).astype(int)
diabetic = (risk_score >= 2).astype(int)   # 1 = diabetic, 0 = not diabetic

df = pd.DataFrame({"Glucose": glucose, "BMI": bmi, "Age": age, "Diabetic": diabetic})
print(df.head())

# ---------- 2. Prepare features/target ----------
X = df[["Glucose", "BMI", "Age"]]
y = df["Diabetic"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ---------- 3. Scale features (VERY important for KNN, since it uses distance) ----------
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ---------- 4. Find a good value of K by testing a few options ----------
accuracies = {}
for k in range(1, 16):
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train_scaled, y_train)
    acc = accuracy_score(y_test, knn.predict(X_test_scaled))
    accuracies[k] = acc

best_k = max(accuracies, key=accuracies.get)
print(f"\nBest K found = {best_k} with accuracy = {accuracies[best_k]:.3f}")

# ---------- 5. Train final model with the best K ----------
model = KNeighborsClassifier(n_neighbors=best_k)
model.fit(X_train_scaled, y_train)
y_pred = model.predict(X_test_scaled)

# ---------- 6. Evaluate ----------
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# ---------- 7. Plot accuracy vs K (helps explain "why this K" in viva) ----------
plt.plot(list(accuracies.keys()), list(accuracies.values()), marker='o')
plt.xlabel("K (number of neighbors)")
plt.ylabel("Accuracy")
plt.title("KNN Accuracy vs K value")
plt.grid(True)
plt.savefig("knn_accuracy_vs_k.png", dpi=150, bbox_inches='tight')
print("Chart saved as knn_accuracy_vs_k.png")
