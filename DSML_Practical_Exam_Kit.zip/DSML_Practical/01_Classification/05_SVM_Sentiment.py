"""
Q5. Customer Sentiment Analysis with SVM
--------------------------------------------
Scenario : An e-commerce company wants to analyze customer reviews.
Task     : Train an SVM to classify reviews as Positive or Negative using text data.

WHY SVM (for text)?
SVM works very well on text data because after converting text into
TF-IDF vectors, the data becomes high-dimensional and sparse -- exactly
the type of data SVM handles best by finding the widest separating margin.

TF-IDF = "Term Frequency - Inverse Document Frequency": gives higher
weight to words that are frequent in ONE review but rare across all
reviews (i.e. more meaningful/unique words), and lowers weight of common
words like "the", "is", etc.
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# ---------- 1. Sample review dataset ----------
reviews = [
    "excellent product loved it works perfectly",
    "amazing quality fast delivery highly recommend",
    "best purchase this year very happy",
    "great value for money will buy again",
    "superb service and awesome packaging",
    "fantastic experience five stars",
    "terrible product broke after one day",
    "worst purchase ever complete waste of money",
    "very disappointed poor quality material",
    "bad experience item arrived damaged",
    "not happy with this product at all",
    "horrible customer service never buying again",
    "good product but delivery was slow",
    "okay quality nothing special",
    "loved the design but price is high",
    "awful packaging item was broken",
]
sentiment = [
    "positive", "positive", "positive", "positive", "positive", "positive",
    "negative", "negative", "negative", "negative", "negative", "negative",
    "positive", "negative", "positive", "negative",
]

df = pd.DataFrame({"review": reviews, "sentiment": sentiment})
print(df)

# ---------- 2. Convert text to TF-IDF numeric features ----------
vectorizer = TfidfVectorizer(stop_words='english')
X = vectorizer.fit_transform(df["review"])
y = df["sentiment"]

# ---------- 3. Train/Test split ----------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# ---------- 4. Train the SVM (linear kernel works best for text) ----------
model = SVC(kernel='linear', C=1.0)
model.fit(X_train, y_train)

# ---------- 5. Predict & Evaluate ----------
y_pred = model.predict(X_test)
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# ---------- 6. Test on a brand-new customer review ----------
new_review = ["the product quality is really bad and slow delivery"]
new_vec = vectorizer.transform(new_review)
prediction = model.predict(new_vec)
print(f"\nNew review: '{new_review[0]}' --> Predicted Sentiment: {prediction[0].upper()}")
