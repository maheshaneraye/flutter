"""
Q4. Email Spam Detection Using Naive Bayes
---------------------------------------------
Scenario : An email service provider wants to filter spam messages.
Task     : Use Naive Bayes to classify emails as Spam or Not Spam (Ham)
           based on word frequency (text data).

WHY NAIVE BAYES?
Naive Bayes uses probability theory (Bayes' Theorem) and ASSUMES every
word in the email is independent of the others ("naive" assumption).
Despite being a simplification, it works extremely well and extremely
fast for text classification like spam filtering.

We build a small sample dataset of email texts directly in the code
(no CSV needed), so this script runs immediately in the exam.
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# ---------- 1. Sample dataset of emails (text + label) ----------
emails = [
    "win money now claim your prize",
    "free lottery winner click here",
    "urgent your account will be closed act now",
    "congratulations you won a free gift card",
    "limited offer buy cheap medicines online",
    "click this link to win a free iphone",
    "meeting scheduled for tomorrow morning",
    "please find attached the project report",
    "let's catch up for lunch this weekend",
    "your invoice for last month is attached",
    "team meeting notes and next steps",
    "reminder submit your assignment by friday",
    "get rich quick with this simple trick",
    "you have been selected for a cash reward",
    "project deadline extended to next week",
    "can we reschedule our call to 3pm",
]
labels = [
    "spam", "spam", "spam", "spam", "spam", "spam",
    "ham", "ham", "ham", "ham", "ham", "ham",
    "spam", "spam",
    "ham", "ham",
]

df = pd.DataFrame({"text": emails, "label": labels})
print(df)

# ---------- 2. Convert text into numeric features (Bag of Words) ----------
# CountVectorizer counts how many times each word appears in each email
vectorizer = CountVectorizer(stop_words='english')
X = vectorizer.fit_transform(df["text"])   # sparse matrix of word counts
y = df["label"]

print("\nVocabulary size:", len(vectorizer.vocabulary_))

# ---------- 3. Train/Test split ----------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# ---------- 4. Train Multinomial Naive Bayes (best for word-count data) ----------
model = MultinomialNB()
model.fit(X_train, y_train)

# ---------- 5. Predict & Evaluate ----------
y_pred = model.predict(X_test)
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# ---------- 6. Test with a brand-new email ----------
new_email = ["free cash prize click now to claim"]
new_email_vec = vectorizer.transform(new_email)
prediction = model.predict(new_email_vec)
print(f"\nNew email: '{new_email[0]}' --> Predicted as: {prediction[0].upper()}")
