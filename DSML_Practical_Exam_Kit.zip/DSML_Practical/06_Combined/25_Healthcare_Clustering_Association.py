"""
Q25. Healthcare Personalization Using Clustering and Association Rules
-------------------------------------------------------------------------------
Scenario : A health provider wants to personalize treatment plans.
Task     : (a) CLUSTER patients by symptoms
           (b) Mine TREATMENT PATTERNS using association rules within
               each patient cluster

This combines TWO unsupervised techniques:
  Step 1 (K-Means Clustering): Group patients who report similar symptom
          severities into the same cluster (e.g. "high fever + high cough"
          patients vs "mostly fatigue" patients).
  Step 2 (Apriori / Association Rules): Within each cluster, find which
          treatments/medicines are commonly given together -- revealing
          personalized treatment patterns PER patient group.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# =====================================================================
# STEP 1: CLUSTER PATIENTS BY SYMPTOMS
# =====================================================================
np.random.seed(25)
n = 200
fever_severity = np.random.uniform(0, 10, n)     # 0 = none, 10 = severe
cough_severity = np.random.uniform(0, 10, n)
fatigue_severity = np.random.uniform(0, 10, n)

symptoms_df = pd.DataFrame({
    "Fever": fever_severity, "Cough": cough_severity, "Fatigue": fatigue_severity
})

scaler = StandardScaler()
symptoms_scaled = scaler.fit_transform(symptoms_df)

K = 3   # e.g. "mild", "respiratory-heavy", "severe/flu-like" clusters
kmeans = KMeans(n_clusters=K, random_state=42, n_init=10)
symptoms_df["Cluster"] = kmeans.fit_predict(symptoms_scaled)

print("Patient counts per cluster:\n", symptoms_df["Cluster"].value_counts())
print("\nAverage symptom severity per cluster:\n",
      symptoms_df.groupby("Cluster")[["Fever", "Cough", "Fatigue"]].mean())

# =====================================================================
# STEP 2: MINE TREATMENT PATTERNS (within the whole dataset, then per cluster)
# =====================================================================
# Assign each patient a set of treatments/medicines (simulated) that
# loosely depends on their cluster, so patterns emerge naturally.
treatment_pool = {
    0: [["paracetamol", "rest"], ["paracetamol", "fluids"], ["rest", "fluids"]],
    1: [["cough_syrup", "steam_inhalation"], ["cough_syrup", "antihistamine"],
        ["steam_inhalation", "antihistamine"]],
    2: [["antibiotics", "paracetamol", "fluids"], ["antibiotics", "rest", "fluids"],
        ["paracetamol", "antibiotics"]],
}

np.random.seed(1)
symptoms_df["Treatments"] = symptoms_df["Cluster"].apply(
    lambda c: treatment_pool[c][np.random.randint(0, len(treatment_pool[c]))]
)
print("\nSample patient records with cluster & treatment:\n", symptoms_df.head())

# ---------- Mine association rules SEPARATELY for each cluster ----------
for cluster_id in sorted(symptoms_df["Cluster"].unique()):
    cluster_treatments = symptoms_df[symptoms_df["Cluster"] == cluster_id]["Treatments"].tolist()

    te = TransactionEncoder()
    te_array = te.fit(cluster_treatments).transform(cluster_treatments)
    trans_df = pd.DataFrame(te_array, columns=te.columns_)

    frequent_itemsets = apriori(trans_df, min_support=0.3, use_colnames=True)
    if len(frequent_itemsets) == 0:
        continue
    rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.6)

    print(f"\n=== Cluster {cluster_id}: Common Treatment Patterns ===")
    if len(rules) > 0:
        print(rules[["antecedents", "consequents", "support", "confidence", "lift"]])
    else:
        print("No strong rules found for this cluster (try lowering min_support).")

print("\nSummary: Each patient cluster (symptom profile) has its own typical "
      "treatment combination -- this is the basis for a personalized treatment plan.")
