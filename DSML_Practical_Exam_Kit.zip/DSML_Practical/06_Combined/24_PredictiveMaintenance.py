"""
Q24. Predictive Maintenance Using Classification and Regression
----------------------------------------------------------------------
Scenario : A manufacturing plant wants to predict machine failures.
Task     : (a) Use CLASSIFICATION to detect the failure TYPE
           (b) Use REGRESSION to estimate TIME-TO-FAILURE (in days)

This question combines TWO models in one pipeline -- very common in
real predictive-maintenance systems:
  Step 1 (Classification): "Is this machine going to fail, and if so what
           TYPE of failure (Mechanical / Electrical / None)?"
  Step 2 (Regression): "IF it will fail, how many days until it fails?"
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score, classification_report, mean_absolute_error, r2_score

# ---------- 1. Create synthetic sensor + maintenance data ----------
np.random.seed(24)
n = 400
temperature = np.random.uniform(40, 120, n)         # machine temperature (C)
vibration = np.random.uniform(0, 10, n)                # vibration level
usage_hours = np.random.uniform(100, 10000, n)          # hours of operation since last service

# ---- Part A: create failure TYPE label (classification target) ----
def get_failure_type(temp, vib, hours):
    if temp > 100 and vib > 6:
        return "Mechanical"
    elif vib < 3 and hours > 7000:
        return "Electrical"
    elif temp < 90 and vib < 5:
        return "None"
    else:
        return np.random.choice(["Mechanical", "Electrical", "None"])

failure_type = [get_failure_type(t, v, h) for t, v, h in zip(temperature, vibration, usage_hours)]

# ---- Part B: create time-to-failure (regression target, only meaningful if failure happens) ----
time_to_failure_days = np.clip(
    100 - (temperature - 40) * 0.5 - vibration * 3 + np.random.normal(0, 5, n), 1, None
)

df = pd.DataFrame({
    "Temperature": temperature, "Vibration": vibration, "UsageHours": usage_hours,
    "FailureType": failure_type, "TimeToFailureDays": time_to_failure_days
})
print(df.head())

X = df[["Temperature", "Vibration", "UsageHours"]]

# =====================================================================
# STEP 1: CLASSIFICATION -- predict the failure type
# =====================================================================
y_class = df["FailureType"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y_class, test_size=0.25, random_state=42, stratify=y_class
)

clf = RandomForestClassifier(n_estimators=200, max_depth=6, random_state=42)
clf.fit(X_train, y_train)
y_pred_class = clf.predict(X_test)

print("\n=== CLASSIFICATION RESULTS (Failure Type) ===")
print("Accuracy:", accuracy_score(y_test, y_pred_class))
print(classification_report(y_test, y_pred_class))

# =====================================================================
# STEP 2: REGRESSION -- predict time to failure (in days)
# =====================================================================
y_reg = df["TimeToFailureDays"]
X_train_r, X_test_r, y_train_r, y_test_r = train_test_split(
    X, y_reg, test_size=0.25, random_state=42
)

reg = RandomForestRegressor(n_estimators=200, max_depth=6, random_state=42)
reg.fit(X_train_r, y_train_r)
y_pred_reg = reg.predict(X_test_r)

print("\n=== REGRESSION RESULTS (Time to Failure) ===")
print("MAE (days):", mean_absolute_error(y_test_r, y_pred_reg))
print("R^2 Score:", r2_score(y_test_r, y_pred_reg))

# ---------- 3. Full pipeline: predict for a brand-new machine reading ----------
new_machine = pd.DataFrame({"Temperature": [105], "Vibration": [7], "UsageHours": [4000]})
predicted_failure_type = clf.predict(new_machine)[0]
predicted_days = reg.predict(new_machine)[0]

print(f"\n--- PREDICTION FOR NEW MACHINE ---")
print(f"Predicted Failure Type : {predicted_failure_type}")
print(f"Predicted Time to Failure : {predicted_days:.1f} days")
