"""
Q17. Image Compression Using K-Means
--------------------------------------
Scenario : A mobile app needs to reduce image sizes.
Task     : Use K-Means to compress images by clustering pixel colors.

WHY K-MEANS FOR IMAGE COMPRESSION?
A color image typically has thousands/millions of unique RGB colors.
K-Means can group all these colors into just K "representative" colors
(the cluster centers). We then replace EVERY pixel's color with its
nearest cluster's color. Fewer unique colors = image can be stored with
fewer bits per pixel = smaller file size, with only a small loss in quality.

This script generates a synthetic colourful image (so it works without
needing any uploaded image file) and compresses it down to K colors.
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# ---------- 1. Create (or load) an image ----------
# Here we build a synthetic 100x100 RGB image with smooth color gradients
# to simulate a real photo. To use YOUR OWN image instead, replace this
# block with:
#     from PIL import Image
#     img = np.array(Image.open("your_image.jpg"))
np.random.seed(17)
h, w = 100, 100
x = np.linspace(0, 1, w)
y = np.linspace(0, 1, h)
xx, yy = np.meshgrid(x, y)
img = np.zeros((h, w, 3))
img[:, :, 0] = xx                                  # Red channel varies left->right
img[:, :, 1] = yy                                  # Green channel varies top->bottom
img[:, :, 2] = (xx + yy) / 2                        # Blue channel is a mix
img = (img * 255).astype(np.uint8)

print("Original image shape:", img.shape)

# ---------- 2. Reshape image into a list of pixels (each pixel = 1 RGB point) ----------
pixels = img.reshape(-1, 3).astype(float)
print("Reshaped into", pixels.shape[0], "pixels, each with 3 color values (R,G,B)")

# ---------- 3. Apply K-Means to find K representative colors ----------
K = 8   # compress down to just 8 colors (try changing this number!)
model = KMeans(n_clusters=K, random_state=42, n_init=10)
labels = model.fit_predict(pixels)          # which cluster each pixel belongs to
compressed_colors = model.cluster_centers_.astype(np.uint8)   # the K representative colors

# ---------- 4. Rebuild the compressed image using only K colors ----------
compressed_pixels = compressed_colors[labels]
compressed_img = compressed_pixels.reshape(h, w, 3)

# ---------- 5. Show original vs compressed image side-by-side ----------
fig, axes = plt.subplots(1, 2, figsize=(10, 5))
axes[0].imshow(img)
axes[0].set_title("Original Image (thousands of colors)")
axes[0].axis('off')

axes[1].imshow(compressed_img)
axes[1].set_title(f"Compressed Image (only {K} colors)")
axes[1].axis('off')

plt.savefig("kmeans_image_compression.png", dpi=150, bbox_inches='tight')
print("\nComparison image saved as kmeans_image_compression.png")
print("Number of unique colors used after compression:", K)
