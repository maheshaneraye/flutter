"""
Q15. Customer Segmentation for Marketing
---------------------------------------------
Scenario : A retail chain wants to target promotions effectively.
Task     : Use K-Means to segment customers by annual spending and age
           (demographics + spending behaviour).

WHY K-MEANS?
K-Means is an UNSUPERVISED algorithm -- there are NO labels telling us
which "segment" a customer belongs to. K-Means groups similar customers
together into K clusters purely based on how close their feature values
are to each other (using distance). It's the standard tool for market
segmentation because it's simple, fast, and gives interpretable groups.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# ---------- 1. Create synthetic customer data ----------
np.random.seed(15)
n = 300
age = np.random.randint(18, 70, n)
annual_spending = np.random.randint(1000, 100000, n)

df = pd.DataFrame({"Age": age, "AnnualSpending": annual_spending})
print(df.head())

# ---------- 2. Scale features (K-Means uses distance, so scaling matters) ----------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(df[["Age", "AnnualSpending"]])

# ---------- 3. Find the best K using the "Elbow Method" ----------
# We try K = 1 to 10 and plot "inertia" (within-cluster sum of squares).
# The "elbow" point (where the curve bends) is usually the best K.
inertia = []
K_range = range(1, 11)
for k in K_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(X_scaled)
    inertia.append(km.inertia_)

plt.plot(K_range, inertia, marker='o')
plt.xlabel("Number of Clusters (K)")
plt.ylabel("Inertia")
plt.title("Elbow Method for Optimal K")
plt.savefig("kmeans_elbow_method.png", dpi=150, bbox_inches='tight')
print("\nElbow chart saved as kmeans_elbow_method.png")
print("(Look at the chart -- pick K where the line starts to flatten, e.g. K=4)")

# ---------- 4. Train final K-Means with chosen K ----------
K = 4   # chosen by looking at the elbow chart above
model = KMeans(n_clusters=K, random_state=42, n_init=10)
df["Segment"] = model.fit_predict(X_scaled)

print("\nCustomer counts per segment:\n", df["Segment"].value_counts())
print("\nSegment-wise average values:\n", df.groupby("Segment")[["Age", "AnnualSpending"]].mean())

# ---------- 5. Visualize the clusters ----------
plt.figure(figsize=(8, 6))
scatter = plt.scatter(df["Age"], df["AnnualSpending"], c=df["Segment"], cmap='viridis')
plt.xlabel("Age")
plt.ylabel("Annual Spending")
plt.title(f"Customer Segments (K={K})")
plt.colorbar(scatter, label="Segment")
plt.savefig("kmeans_customer_segments.png", dpi=150, bbox_inches='tight')
print("Cluster chart saved as kmeans_customer_segments.png")
