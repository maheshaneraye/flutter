"""
Q18. Traffic Pattern Analysis
-----------------------------------
Scenario : A smart city project wants to optimize traffic flow.
Task     : Cluster GPS data (latitude, longitude) to identify congestion
           zones and peak hours.

WHY K-MEANS FOR GPS DATA?
GPS coordinates (lat, long) are naturally 2D numeric points, so K-Means
is a very natural fit -- it groups nearby GPS pings into "zones" of
activity. Dense clusters with many points = high-traffic / congestion
zones the city should focus on.
"""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# ---------- 1. Create synthetic GPS ping data ----------
# We simulate 3 congestion hotspots (like busy junctions) plus general traffic
np.random.seed(18)

hotspot_1 = np.random.normal(loc=[18.52, 73.85], scale=0.01, size=(150, 2))  # busy junction A
hotspot_2 = np.random.normal(loc=[18.55, 73.90], scale=0.008, size=(120, 2))  # busy junction B
hotspot_3 = np.random.normal(loc=[18.50, 73.80], scale=0.012, size=(100, 2))  # busy junction C
scattered = np.random.uniform(low=[18.48, 73.78], high=[18.57, 73.92], size=(80, 2))  # general traffic

gps_points = np.vstack([hotspot_1, hotspot_2, hotspot_3, scattered])
df = pd.DataFrame(gps_points, columns=["Latitude", "Longitude"])
print(df.head())
print("\nTotal GPS pings:", len(df))

# ---------- 2. Apply K-Means to find congestion zones ----------
K = 4   # 3 real hotspots + 1 cluster to catch scattered/background traffic
model = KMeans(n_clusters=K, random_state=42, n_init=10)
df["Zone"] = model.fit_predict(df[["Latitude", "Longitude"]])

# ---------- 3. Identify the busiest zones (most GPS points = most congestion) ----------
zone_counts = df["Zone"].value_counts().sort_values(ascending=False)
print("\nNumber of GPS pings per zone (busiest first):\n", zone_counts)
print("\n--> Zone", zone_counts.index[0], "is the MOST CONGESTED zone.")

# ---------- 4. Visualize the zones on a scatter plot (acts like a mini-map) ----------
plt.figure(figsize=(8, 6))
scatter = plt.scatter(df["Longitude"], df["Latitude"], c=df["Zone"], cmap='tab10', alpha=0.6)
centers = model.cluster_centers_
plt.scatter(centers[:, 1], centers[:, 0], marker='X', s=200, c='black', label='Zone Center')
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.title("Traffic Congestion Zones (K-Means Clustering)")
plt.legend()
plt.savefig("kmeans_traffic_zones.png", dpi=150, bbox_inches='tight')
print("\nMap saved as kmeans_traffic_zones.png")
