"""
Q16. Document Clustering for News Articles
------------------------------------------------
Scenario : A media company wants to organize articles by topic.
Task     : Apply K-Means to cluster articles using TF-IDF features.

WHY K-MEANS + TF-IDF?
Step 1: TF-IDF converts each article's text into a numeric vector
        (see Q5 for full TF-IDF explanation).
Step 2: K-Means groups articles whose TF-IDF vectors are close together
        (i.e. articles that use similar important words) into the same
        cluster -- without us ever telling it the topics in advance.
"""

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

# ---------- 1. Sample news article headlines/snippets (mix of 3 topics) ----------
articles = [
    "stock market rises as investors gain confidence",
    "central bank raises interest rates to control inflation",
    "shares of tech companies rally on strong earnings",
    "team wins championship after thrilling final match",
    "star player scores winning goal in extra time",
    "national team qualifies for world cup finals",
    "scientists discover new exoplanet in distant galaxy",
    "researchers develop breakthrough cancer treatment",
    "new study reveals effects of climate change on oceans",
    "economy shows signs of recovery after recession",
    "football club signs new striker in record deal",
    "space agency announces mission to explore mars",
]

df = pd.DataFrame({"article": articles})

# ---------- 2. Convert text to TF-IDF vectors ----------
vectorizer = TfidfVectorizer(stop_words='english')
X = vectorizer.fit_transform(df["article"])

# ---------- 3. Apply K-Means (we expect roughly 3 topics: finance, sports, science) ----------
K = 3
model = KMeans(n_clusters=K, random_state=42, n_init=10)
df["Cluster"] = model.fit_predict(X)

print(df.sort_values("Cluster"))

# ---------- 4. Inspect top words per cluster (helps label each cluster) ----------
terms = vectorizer.get_feature_names_out()
order_centroids = model.cluster_centers_.argsort()[:, ::-1]   # sort words by importance

print("\nTop words per cluster:")
for i in range(K):
    top_words = [terms[ind] for ind in order_centroids[i, :5]]
    print(f"Cluster {i}: {', '.join(top_words)}")

# ---------- 5. Assign a NEW article to an existing cluster ----------
new_article = ["company profits soar as sales increase this quarter"]
new_vec = vectorizer.transform(new_article)
predicted_cluster = model.predict(new_vec)
print(f"\nNew article: '{new_article[0]}' --> Cluster {predicted_cluster[0]}")
