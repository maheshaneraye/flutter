"""
Q14. Product Recommendation System
----------------------------------------
Scenario : An online store wants to personalize product suggestions.
Task     : Use Random Forest to predict whether a user will LIKE/BUY a
           product based on browsing and purchase history features.

WHY RANDOM FOREST (here)?
This models recommendation as a CLASSIFICATION problem:
"Given how many times a user viewed this category, their past purchase
count, and time spent browsing -- will they buy this product (Yes/No)?"
Random Forest handles this kind of tabular behavioural data very well and
also tells us which browsing behaviour matters most (feature importance).
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# ---------- 1. Create synthetic browsing/purchase data ----------
np.random.seed(14)
n = 400
category_views = np.random.randint(0, 20, n)          # times user viewed this category
past_purchases = np.random.randint(0, 15, n)            # past purchases in this category
time_spent_min = np.random.uniform(0, 30, n)             # minutes spent browsing product page

buy_score = (
    (category_views > 8).astype(int) +
    (past_purchases > 3).astype(int) +
    (time_spent_min > 10).astype(int)
)
will_buy = (buy_score >= 2).astype(int)   # 1 = will buy/like, 0 = won't

df = pd.DataFrame({
    "CategoryViews": category_views,
    "PastPurchases": past_purchases,
    "TimeSpentMin": time_spent_min,
    "WillBuy": will_buy
})
print(df.head())

# ---------- 2. Features & target ----------
X = df[["CategoryViews", "PastPurchases", "TimeSpentMin"]]
y = df["WillBuy"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# ---------- 3. Train Random Forest ----------
model = RandomForestClassifier(n_estimators=200, max_depth=6, random_state=42)
model.fit(X_train, y_train)

# ---------- 4. Predict & Evaluate ----------
y_pred = model.predict(X_test)
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# ---------- 5. Recommend products to a new user (rank by predicted probability) ----------
candidate_products = pd.DataFrame({
    "Product": ["Shoes", "Laptop", "Book", "Headphones", "Watch"],
    "CategoryViews": [12, 3, 15, 9, 2],
    "PastPurchases": [4, 0, 6, 2, 1],
    "TimeSpentMin": [15, 2, 20, 11, 3]
})
probs = model.predict_proba(candidate_products[["CategoryViews", "PastPurchases", "TimeSpentMin"]])[:, 1]
candidate_products["BuyProbability"] = probs
candidate_products = candidate_products.sort_values("BuyProbability", ascending=False)
print("\nRecommended products (ranked by predicted buy probability):")
print(candidate_products[["Product", "BuyProbability"]])
