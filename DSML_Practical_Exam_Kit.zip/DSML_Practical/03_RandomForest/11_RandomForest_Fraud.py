"""
Q11. Fraud Detection in Financial Transactions
--------------------------------------------------
Scenario : A bank wants to detect fraudulent transactions.
Task     : Use Random Forest to classify transactions as Legitimate or Fraudulent.

WHY RANDOM FOREST?
A Random Forest builds MANY decision trees (a "forest"), each trained on a
random subset of data/features, then takes a MAJORITY VOTE of all trees'
predictions. This reduces overfitting (a problem single decision trees have)
and generally gives higher accuracy -- ideal for high-stakes tasks like fraud
detection where a single tree's mistake could be costly.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# ---------- 1. Create synthetic transaction data ----------
np.random.seed(11)
n = 500
transaction_amount = np.random.exponential(scale=200, size=n)      # most small, few large
transaction_hour = np.random.randint(0, 24, n)                       # hour of day (0-23)
distance_from_home_km = np.random.exponential(scale=20, size=n)      # distance from usual location

# Rule: very large amount + odd hour (late night) + far from home -> likely fraud
fraud_score = (
    (transaction_amount > 800).astype(int) +
    ((transaction_hour < 5) | (transaction_hour > 23)).astype(int) +
    (distance_from_home_km > 100).astype(int)
)
is_fraud = (fraud_score >= 2).astype(int)

df = pd.DataFrame({
    "Amount": transaction_amount,
    "Hour": transaction_hour,
    "DistanceFromHome_km": distance_from_home_km,
    "IsFraud": is_fraud
})
print(df.head())
print("\nFraud cases in data:", df["IsFraud"].sum(), "out of", len(df))

# ---------- 2. Features & target ----------
X = df[["Amount", "Hour", "DistanceFromHome_km"]]
y = df["IsFraud"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# ---------- 3. Train Random Forest ----------
# n_estimators = number of trees in the forest
model = RandomForestClassifier(n_estimators=200, max_depth=6, random_state=42)
model.fit(X_train, y_train)

# ---------- 4. Predict & Evaluate ----------
y_pred = model.predict(X_test)
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# ---------- 5. Which feature matters most for detecting fraud? ----------
importance = pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=False)
print("\nFeature Importance:\n", importance)

# ---------- 6. Check a new suspicious transaction ----------
new_txn = pd.DataFrame({"Amount": [950], "Hour": [3], "DistanceFromHome_km": [150]})
prediction = model.predict(new_txn)
proba = model.predict_proba(new_txn)[0][1]
print(f"\nNew transaction prediction: {'FRAUD' if prediction[0]==1 else 'LEGITIMATE'} "
      f"(fraud probability = {proba*100:.1f}%)")
