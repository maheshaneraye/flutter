"""
Q13. Air Quality Classification
------------------------------------
Scenario : A city council wants to monitor pollution levels.
Task     : Use Random Forest to classify AQI (Air Quality Index) levels
           (Good / Moderate / Poor) based on sensor data (PM2.5, PM10, CO).

WHY RANDOM FOREST?
This is a MULTI-CLASS classification problem (3 categories, not just 2).
Random Forest naturally handles multi-class problems and gives robust
results even when sensor readings are noisy.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# ---------- 1. Create synthetic sensor data ----------
np.random.seed(13)
n = 400
pm25 = np.random.uniform(5, 300, n)     # PM2.5 concentration
pm10 = np.random.uniform(10, 400, n)     # PM10 concentration
co = np.random.uniform(0.1, 10, n)        # Carbon monoxide level

def classify_aqi(p25, p10, co_level):
    """Simple rule to assign an AQI category (used only to build training labels)."""
    if p25 < 60 and p10 < 100 and co_level < 2:
        return "Good"
    elif p25 < 150 and p10 < 250 and co_level < 5:
        return "Moderate"
    else:
        return "Poor"

aqi_class = [classify_aqi(a, b, c) for a, b, c in zip(pm25, pm10, co)]

df = pd.DataFrame({"PM2_5": pm25, "PM10": pm10, "CO": co, "AQI_Class": aqi_class})
print(df.head())
print("\nClass distribution:\n", df["AQI_Class"].value_counts())

# ---------- 2. Features & target ----------
X = df[["PM2_5", "PM10", "CO"]]
y = df["AQI_Class"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# ---------- 3. Train Random Forest (multi-class works automatically) ----------
model = RandomForestClassifier(n_estimators=200, max_depth=6, random_state=42)
model.fit(X_train, y_train)

# ---------- 4. Predict & Evaluate ----------
y_pred = model.predict(X_test)
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred, labels=["Good", "Moderate", "Poor"]))
print("Classification Report:\n", classification_report(y_test, y_pred))

# ---------- 5. Predict AQI class for new sensor reading ----------
new_reading = pd.DataFrame({"PM2_5": [180], "PM10": [220], "CO": [4.5]})
prediction = model.predict(new_reading)
print(f"\nNew sensor reading predicted AQI class: {prediction[0]}")
