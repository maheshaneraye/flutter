"""
Q12. Employee Attrition Prediction
---------------------------------------
Scenario : An HR department wants to reduce employee turnover.
Task     : Train a Random Forest model to predict attrition (employee leaving)
           using job satisfaction score and performance rating.

WHY RANDOM FOREST?
HR data usually has a mix of factors that interact in complex, non-linear
ways (e.g. low satisfaction ONLY matters if performance is also average).
Random Forest can automatically capture such interactions without us
having to manually specify them, unlike plain linear models.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt

# ---------- 1. Create synthetic HR data ----------
np.random.seed(12)
n = 400
job_satisfaction = np.random.randint(1, 11, n)     # scale 1-10
performance_rating = np.random.randint(1, 6, n)      # scale 1-5
years_at_company = np.random.randint(0, 20, n)

attrition_score = (
    (job_satisfaction <= 4).astype(int) +
    (performance_rating <= 2).astype(int) +
    (years_at_company < 1).astype(int)
)
attrition = (attrition_score >= 2).astype(int)   # 1 = left the company, 0 = stayed

df = pd.DataFrame({
    "JobSatisfaction": job_satisfaction,
    "PerformanceRating": performance_rating,
    "YearsAtCompany": years_at_company,
    "Attrition": attrition
})
print(df.head())

# ---------- 2. Features & target ----------
X = df[["JobSatisfaction", "PerformanceRating", "YearsAtCompany"]]
y = df["Attrition"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# ---------- 3. Train Random Forest ----------
model = RandomForestClassifier(n_estimators=150, max_depth=5, random_state=42)
model.fit(X_train, y_train)

# ---------- 4. Predict & Evaluate ----------
y_pred = model.predict(X_test)
print("\nAccuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# ---------- 5. Feature importance chart ----------
importance = pd.Series(model.feature_importances_, index=X.columns).sort_values()
importance.plot(kind='barh', color='teal')
plt.title("Feature Importance - Employee Attrition")
plt.xlabel("Importance")
plt.savefig("attrition_feature_importance.png", dpi=150, bbox_inches='tight')
print("\nChart saved as attrition_feature_importance.png")

# ---------- 6. Predict for a new employee ----------
new_employee = pd.DataFrame({"JobSatisfaction": [3], "PerformanceRating": [2], "YearsAtCompany": [0]})
prediction = model.predict(new_employee)
print(f"\nNew employee prediction: {'LIKELY TO LEAVE' if prediction[0]==1 else 'LIKELY TO STAY'}")
